package org.rrd4j.graph;

import java.awt.*;

class Area extends SourcedPlotElement {
    Area(String srcName, Paint color) {
        super(srcName, color);
    }
}
