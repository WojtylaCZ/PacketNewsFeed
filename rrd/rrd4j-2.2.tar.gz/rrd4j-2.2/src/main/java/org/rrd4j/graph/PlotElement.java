package org.rrd4j.graph;

import java.awt.*;

class PlotElement {
    final Paint color;

    PlotElement(Paint color) {
        this.color = color;
    }
}
